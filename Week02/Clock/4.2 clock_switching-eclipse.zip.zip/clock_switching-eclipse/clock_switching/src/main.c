/*
 * main.c
 *
 *  Created on: 05-Jul-2019
 *      Author: DELL
 */


#include <stdint.h>
#ifdef USE_STDPERIPH_DRIVER
#include "stm32f4xx_conf.h"
#endif /* USE_STDPERIPH_DRIVER */

//we will switch the clock source to HSE
int main(void)
{
  RCC_TypeDef *pRCC;
  pRCC= RCC;
 //1. turn on the HSE Oscillator
  pRCC->CR |= (1<<16);
 //2. wait until the HSE becomes stable.crystal oscillator takes more time than the RC oscillator to become stable
  while( ! (pRCC->CR & (1<<17)));

 //3. Select HSE as the system clock
  pRCC->CFGR &= ~(0x3 <<0);
  pRCC->CFGR |=(0x1 <<0);

return 0;
}
